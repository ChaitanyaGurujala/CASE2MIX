sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("case02fe.controller.X1",{onInit:function(){}})});
//# sourceMappingURL=X1.controller.js.map
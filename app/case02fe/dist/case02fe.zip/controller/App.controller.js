sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("case02fe.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map
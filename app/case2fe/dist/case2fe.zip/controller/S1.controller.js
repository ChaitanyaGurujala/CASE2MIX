sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("case2fe.controller.S1",{onInit:function(){}})});
//# sourceMappingURL=S1.controller.js.map
sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("case2fe.controller.S1", {
        onInit: function () {

        }
    });
});
